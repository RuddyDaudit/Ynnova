<!DOCTYPE html>
<html>
<head>
	<title>Services</title>
</head>
<body>
<div class="container">
	<header>
	<h1 class="display-3">Nos Services</h1>
	</header>
</div>
<div>
	<table>
		<tr>
    		<td>IMG</td>
    		<td>IMG</td>
    		<td>IMG</td>
  		</tr>
  		<tr>
    		<td>Communication</td>
    		<td>Infographie</td>
    		<td>Développement</td>
  		</tr>
  		<tr>
    		<td>
    			<p>
    			fdfddddfdfdffdfdfddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
    			</p>
    		</td>
    		<td>
    			<p>
    			fdfddddfdfdffdfdfddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
    			</p>
    		</td>
    		<td>
    			<p>
    			fdfddddfdfdffdfdfddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd
    			</p>
    		</td>
  		</tr>
		
	</table>
</div>

</body>
</html>